import numpy as np


class MemoryScheduler(object):
    USE_INPLACE = True

    def __init__(self, layer, precision=8, FP_output=False):
        self.layer = layer
        self.heads = 0
        self.buffers = {
            "input_output": 0,
            "residual": 0,
            "im2col": 0,
            "kernel": 0,
            "feature": 0,
        }  # for feature pyramid
        # overall memory info
        # currently we only support MoblieNet-like models which only have 1 by-pass for a block
        self.peakmem = 0
        self.flash = 0
        self.bias = 0
        self.scale = 0
        self.code = 0
        self.BIT = precision
        self.FP_output = FP_output

        # for showing layer-wise memory usage
        self.layermem = []

    # public functions
    def allocateMemory(self):
        # binary code
        self.__allocateBinaryCode()

        # varaiables to maintain tensors of previous layer
        previous_output_add = "front"  # input is place at &buffer0[0]

        # For detailed memory
        for i in range(len(self.layer)):
            layermem = {}
            self.layermem.append(layermem)

        # for SE Block
        previous_se_out = "head"  # head or tail
        SE_inputSize = 0
        se_out_add = None

        # go through all layers, figure out the placement of each tensors, and enlarge bufer size
        for i, op in enumerate(self.layer):
            layer_info = op.get_layer_info()
            if "is_SEBlock" in layer_info and layer_info["is_SEBlock"]:
                # first op, should be average pooling
                previous_layer_info = previous_layer_info.get_layer_info()
                if (
                    "is_SEBlock" in previous_layer_info
                    and not previous_layer_info["is_SEBlock"]
                ):
                    # Previously inplace depthwise
                    SE_inputSize = self.__flatsize(previous_layer_info, "output")
                    if previous_output_add == "front":
                        se_out_add = "front"
                    else:
                        se_out_add = "end"

                    previous_se_out = "head"  # reset it for simple placement,

                    # For buffer assignement, previously inplace depthwise
                    layer_info["input_buf_add"] = previous_layer_info["input_buf_add"]
                else:
                    # For buffer assignement
                    layer_info["input_buf_add"] = previous_layer_info["output_buf_add"]
                layer_info.output_tensor[0].buffer_placement = se_out_add
                # layer_info["output_buf_add"] = se_out_add

                # For detailed memory
                if layer_info["op"] == "CONV_2D":  # (MAC)
                    self.layermem[i]["MAC"] = op.get_macs()

                # For address assignment
                layer_info["SE_inputLocation"] = previous_output_add
                layer_info["SE_inputSize"] = SE_inputSize
                if previous_se_out == "head":
                    layer_info["SE_location"] = "tail"
                    previous_se_out = layer_info["SE_location"]
                else:
                    layer_info["SE_location"] = "head"
                    previous_se_out = layer_info["SE_location"]

                continue

            """ find the life cycle of the output """
            output_idx = layer_info["output_idx"]
            # scan if the output is used for residual
            output_residual = False
            # For detailed memory (find the residual output pf this layer)
            residual_index = 0
            for j in range(i + 2, len(self.layer)):
                j_layer_info = self.layer[j].get_layer_info()
                if j_layer_info["input_idx"] == output_idx:
                    output_residual = True
                    residual_index = j
                    break
                if (
                    j_layer_info["op"] == "ADD"
                    and j_layer_info["input2_idx"] == output_idx
                ):
                    output_residual = True
                    residual_index = j
                    break

            # For detailed memory (MAC)
            if layer_info["op"] == "DEPTHWISE_CONV_2D":
                self.layermem[i]["MAC"] = op.get_macs()
            if layer_info["op"] == "CONV_2D":
                self.layermem[i]["MAC"] = op.get_macs()

            # For detailed memory (residual buffer for a number of following layers)
            output_size = self.__flatsize(layer_info, "output")
            for j in range(i + 1, residual_index):
                self.layermem[j]["residual"] = output_size

            """ assign the output address """
            if "fpn_output_key" in layer_info:
                layer_info["output_buf_add"] = layer_info["fpn_output_key"]
            elif "dagop_output_key" in layer_info:
                layer_info["output_buf_add"] = layer_info["dagop_output_key"]
            else:
                if output_residual:
                    # place it in the residual buf
                    layer_info["output_buf_add"] = "residual"
                else:
                    if previous_output_add == "end":
                        if layer_info["op"] == "DEPTHWISE_CONV_2D" and self.USE_INPLACE:
                            # place it inplace
                            layer_info["output_buf_add"] = "end"
                        else:
                            # place it inplace
                            layer_info["output_buf_add"] = "front"
                    else:
                        if layer_info["op"] == "DEPTHWISE_CONV_2D" and self.USE_INPLACE:
                            # place it inplace
                            layer_info["output_buf_add"] = "front"
                        else:
                            # place it inplace
                            layer_info["output_buf_add"] = "end"

            """ assign the input address and enlarge buffer """
            input_size = self.__flatsize(layer_info, "input")
            if layer_info["op"] == "DEPTHWISE_CONV_2D" and self.USE_INPLACE:
                output_size = 0  # layer_info["output_h"] * layer_info["output_w"] * 2
            else:
                output_size = self.__flatsize(layer_info, "output")
                if (
                    layer_info["output_scale"] is not None
                    and self.FP_output
                    # TODO: double check this is correct on-board before using these to them to tile memory
                    # and "effective_scale" in layer_info
                    # and layer_info["effective_scale"] is not None
                ):
                    output_size *= 4

            if "fpn_output_key" in layer_info:
                # fpn output node
                # 1. enlarge the input_output buffer
                if output_residual:
                    self.__enlargeBuffer(layer_info["fpn_output_key"], input_size)
                else:
                    self.__enlargeBuffer("input_output", input_size)
                    self.__enlargeBuffer(layer_info["fpn_output_key"], output_size)
                # 2. assign address and enlarge residual buffer if needed (e.g., ADD)
                if layer_info["op"] == "ADD":  # two inputs
                    layer_info["input_buf_add"] = previous_output_add
                    layer_info["input2_buf_add"] = "residual"

                    self.__enlargeBuffer("residual", input_size)

                    # For detailed memory
                    self.layermem[i]["activation"] = input_size + output_size

                else:  # one input
                    layer_info["input_buf_add"] = previous_output_add

                    # For detailed memory
                    self.layermem[i]["activation"] = input_size + output_size
            elif "dagop_output_key" in layer_info:
                # det output node
                # 1. enlarge the input_output buffer
                if output_residual:
                    self.__enlargeBuffer(layer_info["dagop_output_key"], input_size)
                else:
                    self.__enlargeBuffer("input_output", input_size)
                    self.__enlargeBuffer(layer_info["dagop_output_key"], output_size)

                # 2. assign address and enlarge residual buffer if needed (e.g., ADD)
                if layer_info["op"] == "ADD":  # two inputs
                    layer_info["input_buf_add"] = previous_output_add
                    layer_info["input2_buf_add"] = "residual"

                    self.__enlargeBuffer("residual", input_size)

                    # For detailed memory
                    self.layermem[i]["activation"] = input_size + output_size

                else:  # one input
                    layer_info["input_buf_add"] = previous_output_add

                    # For detailed memory
                    self.layermem[i]["activation"] = input_size + output_size
            else:
                # backbone
                # 1. enlarge the input_output buffer
                if output_residual:
                    self.__enlargeBuffer("input_output", input_size)
                else:
                    self.__enlargeBuffer("input_output", input_size + output_size)
                # 2. assign address and enlarge residual buffer if needed (e.g., ADD)
                if layer_info["op"] == "ADD":  # two inputs
                    layer_info["input_buf_add"] = previous_output_add
                    layer_info["input2_buf_add"] = "residual"

                    self.__enlargeBuffer("residual", input_size)

                    # For detailed memory
                    self.layermem[i]["activation"] = input_size + output_size

                else:  # one input
                    layer_info["input_buf_add"] = previous_output_add

                    # For detailed memory
                    self.layermem[i]["activation"] = input_size + output_size

            # for first layer of a dag op
            if "dagop_input0_key" in layer_info:
                layer_info["input_buf_add"] = layer_info["dagop_input0_key"]
            if "dagop_input1_key" in layer_info:
                layer_info["input2_buf_add"] = layer_info["dagop_input1_key"]
            """ update previous output address """
            previous_output_add = layer_info["output_buf_add"]

        # now we have the buffer size for input/output tensors
        # go through all layers again to (1) assign specific address for each tensor and (2) enlarge intermediate buffers
        for i, op in enumerate(self.layer):
            layer_info = op.get_layer_info()
            # assign memory addresses for SE blocks
            if "is_SEBlock" in layer_info and layer_info["is_SEBlock"]:
                # first op, previously should be inplace depthwise
                if (
                    "is_SEBlock" in previous_layer_info
                    and not previous_layer_info["is_SEBlock"]
                ):
                    layer_info["input_buf_add_offset"] = previous_layer_info[
                        "input_buf_add_offset"
                    ]
                else:
                    layer_info["input_buf_add_offset"] = previous_layer_info[
                        "output_buf_add_offset"
                    ]

                if layer_info["op"] == "SE_ELEMENT_MULT_2D":  # inplace update
                    layer_info["input2_buf_add"] = layer_info["SE_inputLocation"]
                    layer_info["input2_buf_add_offset"] = self.__getBufferAddress(
                        layer_info["SE_inputLocation"], layer_info["SE_inputSize"]
                    )
                    layer_info["output_buf_add_offset"] = self.__getBufferAddress(
                        layer_info["SE_inputLocation"], layer_info["SE_inputSize"]
                    )
                else:
                    layer_info["output_buf_add_offset"] = self.__getSEBufferAddress(
                        layer_info["SE_inputLocation"],
                        layer_info["SE_inputSize"],
                        layer_info["SE_location"],
                        self.__flatsize(layer_info, "output"),
                    )

                # For detailed memory
                im2col_size = 0
                kernel_size = 0
                weight_size = 0
                bias_size = 0
                scale_size = 0
                activation_size = 0
                if layer_info["op"] == "CONV_2D":
                    im2col_size = (
                        2
                        * 2
                        * layer_info["kernel_h"]
                        * layer_info["kernel_w"]
                        * layer_info["input_c"]
                    )  # 16 bit
                    weight_size = (
                        layer_info["kernel_h"]
                        * layer_info["kernel_w"]
                        * layer_info["input_c"]
                        * layer_info["output_c"]
                    )
                    bias_size = 4 * layer_info["output_c"]
                    scale_size = 8 * layer_info["output_c"]

                if layer_info["op"] == "SE_ELEMENT_MULT_2D":
                    activation_size = self.__flatsize(
                        layer_info, "input2"
                    ) + self.__flatsize(layer_info, "input")
                else:
                    activation_size = self.__flatsize(
                        layer_info, "input"
                    ) + self.__flatsize(layer_info, "input")

                self.layermem[i]["runtime"] = kernel_size + im2col_size
                self.layermem[i]["weight"] = weight_size
                self.layermem[i]["bias"] = bias_size  # bias
                self.layermem[i]["scale"] = scale_size  # shift and multiplier
                self.layermem[i]["activation"] = activation_size

                self.__increaseFlash(weight_size)
                self.__increaseBias(bias_size)
                self.__increaseScale(scale_size)

                continue

            # (1) assign specific address for each tensor
            # input
            # if the previous layer is depthwise, referred to its input
            previous_layer_info = self.layer[i - 1].get_layer_info()
            if (
                i > 0
                and previous_layer_info["op"] == "DEPTHWISE_CONV_2D"
                and self.USE_INPLACE
            ):
                layer_info["input_buf_add_offset"] = self.__getBufferAddress(
                    previous_layer_info["input_buf_add"],
                    self.__flatsize(previous_layer_info, "input"),
                )
            else:
                layer_info["input_buf_add_offset"] = self.__getBufferAddress(
                    layer_info["input_buf_add"], self.__flatsize(layer_info, "input")
                )
            # output
            if layer_info["op"] == "DEPTHWISE_CONV_2D" and self.USE_INPLACE:
                if layer_info["output_buf_add"] == "front":
                    layer_info["output_buf_add_offset"] = self.__getBufferAddress(
                        "end", self.__flatsize(layer_info, "output")
                    )
                else:
                    layer_info["output_buf_add_offset"] = self.__getBufferAddress(
                        "front", self.__flatsize(layer_info, "output")
                    )
            else:
                layer_info["output_buf_add_offset"] = self.__getBufferAddress(
                    layer_info["output_buf_add"], self.__flatsize(layer_info, "output")
                )
            if layer_info["op"] == "ADD":  # two inputs
                layer_info["input2_buf_add_offset"] = self.__getBufferAddress(
                    layer_info["input2_buf_add"], self.__flatsize(layer_info, "input2")
                )
            else:
                # (2) enlarge intermediate buffers
                if layer_info["op"] == "DEPTHWISE_CONV_2D":
                    if self.USE_INPLACE:
                        im2col_size = (
                            2
                            * (layer_info["input_h"] + 2 * layer_info["padding"])
                            * (layer_info["input_w"] + 2 * layer_info["padding"])
                        )
                        kernel_size = 0
                    else:
                        im2col_size = (
                            2
                            * layer_info["kernel_h"]
                            * layer_info["kernel_w"]
                            * layer_info["input_c"]
                        )  # 16 bit
                        kernel_size = (
                            2
                            * (layer_info["kernel_h"] * layer_info["kernel_w"] + 1)
                            * layer_info["input_c"]
                        )  # 16 bit
                    weight_size = (
                        layer_info["kernel_h"]
                        * layer_info["kernel_w"]
                        * layer_info["input_c"]
                    )

                    self.__enlargeBuffer("im2col", im2col_size)
                    self.__enlargeBuffer("kernel", kernel_size)

                    # For detailed memory
                    self.layermem[i]["runtime"] = kernel_size + im2col_size
                    self.layermem[i]["weight"] = weight_size
                    self.layermem[i]["bias"] = 4 * layer_info["output_c"]  # bias
                    # shift and multiplier
                    self.layermem[i]["scale"] = 8 * layer_info["output_c"]

                    self.__increaseFlash(weight_size)
                    # 32-bit bias, shift, multiplier
                    self.__increaseBias(1 * 4 * layer_info["output_c"])
                    # 32-bit bias, shift, multiplier
                    self.__increaseScale(2 * 4 * layer_info["output_c"])
                elif layer_info["op"] == "CONV_2D":
                    im2col_size = (
                        2
                        * 2
                        * layer_info["kernel_h"]
                        * layer_info["kernel_w"]
                        * layer_info["input_c"]
                    )  # 16 bit
                    if layer_info["kernel_h"] == 1 and layer_info["kernel_w"] == 1:
                        kernel_size = 0
                    elif layer_info["stride_h"] == 2 and layer_info["input_c"] == 3:
                        kernel_size = (
                            2
                            * layer_info["kernel_h"]
                            * layer_info["kernel_w"]
                            * layer_info["input_c"]
                            * layer_info["output_c"]
                        )  # 16 bit
                    else:
                        kernel_size = 0
                    weight_size = (
                        layer_info["kernel_h"]
                        * layer_info["kernel_w"]
                        * layer_info["input_c"]
                        * layer_info["output_c"]
                    )

                    self.__enlargeBuffer("im2col", im2col_size)
                    self.__enlargeBuffer("kernel", kernel_size)
                    # For detailed memory
                    self.layermem[i]["runtime"] = kernel_size + im2col_size
                    self.layermem[i]["weight"] = weight_size
                    self.layermem[i]["bias"] = 4 * layer_info["output_c"]  # bias
                    # shift and multiplier
                    self.layermem[i]["scale"] = 8 * layer_info["output_c"]

                    self.__increaseFlash(weight_size)
                    # 32-bit bias, shift, multiplier
                    self.__increaseBias(1 * 4 * layer_info["output_c"])
                    # 32-bit bias, shift, multiplier
                    self.__increaseScale(2 * 4 * layer_info["output_c"])
                elif layer_info["op"] == "FULLY_CONNECTED":
                    weight_size = layer_info["input_c"] * layer_info["output_c"]

                    # For detailed memory
                    self.layermem[i]["weight"] = weight_size
                    self.layermem[i]["bias"] = 4 * layer_info["output_c"]  # bias

                    self.__increaseFlash(weight_size)
                    # 32-bit bias, shift, multiplier
                    self.__increaseBias(1 * 4 * layer_info["output_c"])

        # memory alignment: round up to multiple of 4
        import math

        for b_str in self.buffers:
            self.buffers[b_str] = math.ceil(self.buffers[b_str] / 4) * 4

        ###### tie the memory shcedule for dagop #######
        start_idx = 0
        for start_idx in range(len(self.layer)):
            layer_info = self.layer[start_idx].get_layer_info()
            if "end_of_backbone" in layer_info and layer_info["end_of_backbone"]:
                start_idx += 1
                break

        # measure the max front and max tail
        front = 0
        tail = 0
        buffer_size = int(self.buffers["input_output"])
        while start_idx < len(self.layer):
            layer_info = self.layer[start_idx].get_layer_info()
            # input
            if layer_info["input_buf_add"] == "front":
                front = max(
                    front,
                    layer_info["input_h"]
                    * layer_info["input_w"]
                    * layer_info["input_c"],
                )
            elif layer_info["input_buf_add"] == "end":
                tail = max(tail, buffer_size - layer_info["input_buf_add_offset"])
            # output
            if (
                layer_info["output_buf_add"] == "front"
                and layer_info["op"] != "DEPTHWISE_CONV_2D"
            ):  # skip inplace update
                front = max(
                    front,
                    layer_info["output_h"]
                    * layer_info["output_w"]
                    * layer_info["output_c"],
                )
            elif (
                layer_info["output_buf_add"] == "end"
                and layer_info["op"] != "DEPTHWISE_CONV_2D"
            ):  # skip inplace update
                tail = max(tail, buffer_size - layer_info["output_buf_add_offset"])
            start_idx += 1

        # for fpn outputs
        emptyspace_ptr = front
        fpn_size = 0
        for b in self.buffers:
            if b.startswith("stage"):
                if emptyspace_ptr + self.buffers[b] > buffer_size - tail:
                    fpn_size += int(self.buffers[b])
                else:
                    front += int(self.buffers[b])
        # for det heads outputs
        dag_size = 0
        for b in self.buffers:
            if b.startswith("dagop"):
                if emptyspace_ptr + self.buffers[b] > buffer_size - tail:
                    dag_size += int(self.buffers[b])
                else:
                    front += int(self.buffers[b])
        self.front = front
        ###### tie the memory shcedule for dagop #######

        self.peakmem = (
            self.buffers["im2col"]
            + self.buffers["kernel"]
            + self.buffers["input_output"]
            + self.buffers["residual"]
            + fpn_size
            + dag_size
        )

    def dumpLayerMem(self):
        # header
        print(
            "----------------------------------------------------  Schedule Details ----------------------------------------------------------------"
        )
        print(
            "----------------------|                      SRAM                      ||                     Flash                      |             |"
        )
        print(
            "----------------------|  activation  |  runtime  |  residual  |  sum   ||   weight   |   bias   |  scale   |     sum     |     MAC     |"
        )

        layermem = self.layermem
        self.__dumpMemInfo(layermem)

    def __dumpMemInfo(self, layermem):
        string = "-------Schedule-------|"
        maxActive = self.buffers["input_output"]
        maxRuntime = self.buffers["im2col"] + self.buffers["kernel"]
        maxResidual = self.buffers["residual"]
        totalWeight = self.__sumKey(layermem, "weight")
        totalBias = self.__sumKey(layermem, "bias")
        totalScale = self.__sumKey(layermem, "scale")
        totalMAC = self.__sumKey(layermem, "MAC")
        string += str(maxActive).ljust(14) + "|"
        string += str(maxRuntime).ljust(11) + "|"
        string += str(maxResidual).ljust(12) + "|"
        string += str(maxActive + maxRuntime + maxResidual).ljust(8) + "||"
        string += str(totalWeight).ljust(12) + "|"
        string += str(totalBias).ljust(10) + "|"
        string += str(totalScale).ljust(10) + "|"
        string += str(totalWeight + totalBias + totalScale).ljust(13) + "|"
        string += str(totalMAC).ljust(13) + "|"
        print(string)
        for i in range(len(layermem)):
            layer_info = self.layer[i].get_layer_info()
            string = ""
            string += str(i) + ":" + layer_info["op"]
            string = string.ljust(22) + "|"
            SRAM = 0
            if "activation" in layermem[i]:
                substr = (
                    str(layermem[i]["activation"])
                    + " ("
                    + "{:.0%}".format(layermem[i]["activation"] / maxActive)
                    + ")"
                )
                string += substr.ljust(14) + "|"
                SRAM += layermem[i]["activation"]
            if "runtime" in layermem[i]:
                substr = (
                    str(layermem[i]["runtime"])
                    + " ("
                    + "{:.0%}".format(layermem[i]["runtime"] / maxRuntime)
                    + ")"
                )
                string += substr.ljust(11) + "|"
                SRAM += layermem[i]["runtime"]
            else:
                string = string.ljust(49) + "|"
            if "residual" in layermem[i]:
                substr = (
                    str(layermem[i]["residual"])
                    + " ("
                    + "{:.0%}".format(layermem[i]["residual"] / maxResidual)
                    + ")"
                )
                string += substr.ljust(12) + "|"
                SRAM += layermem[i]["residual"]
            else:
                string = string.ljust(62) + "|"

            # SRAM end
            string += str(SRAM)
            string = string.ljust(71) + "||"
            flash = 0
            if "weight" in layermem[i]:
                substr = (
                    str(layermem[i]["weight"])
                    + " ("
                    + "{:.0%}".format(layermem[i]["weight"] / totalWeight)
                    + ")"
                )
                string += str(substr).ljust(12) + "|"
                flash += layermem[i]["weight"]
            if "bias" in layermem[i]:
                substr = (
                    str(layermem[i]["bias"])
                    + " ("
                    + "{:.0%}".format(layermem[i]["bias"] / totalBias)
                    + ")"
                )
                string += str(substr).ljust(10) + "|"
                flash += layermem[i]["bias"]
            if "scale" in layermem[i]:
                substr = (
                    str(layermem[i]["scale"])
                    + " ("
                    + "{:.0%}".format(layermem[i]["scale"] / totalScale)
                    + ")"
                )
                string += str(substr).ljust(10) + "|"
                flash += layermem[i]["scale"]

                if flash > 0:
                    string += (
                        str(flash)
                        + " ("
                        + "{:.0%}".format(
                            flash / (totalWeight + totalBias + totalScale)
                        )
                        + ")"
                    )
                    string = string.ljust(121) + "|"
            # flash end
            if "MAC" in layermem[i]:
                substr = (
                    str(layermem[i]["MAC"])
                    + " ("
                    + "{:.0%}".format(layermem[i]["MAC"] / totalMAC)
                    + ")"
                )
                string += str(substr).ljust(13) + "|"
            print(string)

    def __sumKey(self, layers, key):
        result = 0
        for l in range(len(layers)):
            if key in layers[l]:
                result += layers[l][key]

        return result

    def getBuffers(self):
        return self.buffers

    # Maximum binary size: This should be updated if any change in the inference side
    # TODO: Combine with code generation to get more accurate result
    def profileResult(self):
        return self.peakmem, self.flash + self.bias + self.scale + int(self.code * 1024)

    # Code size in kB, update this if when using different versions of inference engine/compile options
    CodeSizeTable = {
        "CONV_1x1": 11.23,
        "CONV_3x3_s1_p1": 2.28,
        "CONV_3x3_s2_p1": 1.89,
        "CONV_3x2_s2_p1": 1,
        "CONV_2x3_s2_p1": 1,
        "CONV_10x4_s2_p5": 0,
        "DEPTHWISE_3x1_s1_p1_IP": 0,
        "DEPTHWISE_3x2_s1_p1_IP": 0,
        "DEPTHWISE_1x3_s1_p1_IP": 0,
        "DEPTHWISE_2x3_s1_p1_IP": 0,
        "DEPTHWISE_3x3_s1_p1": 2.45,
        "DEPTHWISE_3x3_s2_p1": 2.39,
        "DEPTHWISE_5x1_s1_p2_IP": 0,
        "DEPTHWISE_5x2_s1_p2_IP": 0,
        "DEPTHWISE_1x5_s1_p2_IP": 0,
        "DEPTHWISE_2x5_s1_p2_IP": 0,
        "DEPTHWISE_5x5_s1_p2": 3.41,
        "DEPTHWISE_5x5_s2_p2": 3.14,
        "DEPTHWISE_7x7_s1_p3": 4.77,
        "DEPTHWISE_7x7_s2_p3": 4.9,
        "DEPTHWISE_7x1_s1_p3_IP": 0,
        "DEPTHWISE_7x2_s1_p3_IP": 0,
        "DEPTHWISE_1x7_s1_p3_IP": 0,
        "DEPTHWISE_2x7_s1_p3_IP": 0,
        "DEPTHWISE_3x1_s2_p1_IP": 0,
        "DEPTHWISE_3x2_s2_p1_IP": 0,
        "DEPTHWISE_1x3_s2_p1_IP": 0,
        "DEPTHWISE_2x3_s2_p1_IP": 0,
        "DEPTHWISE_3x3_s1_p1_IP": 4.75,
        "DEPTHWISE_3x3_s2_p1_IP": 4.35,
        "DEPTHWISE_5x1_s2_p2_IP": 0,
        "DEPTHWISE_5x2_s2_p2_IP": 0,
        "DEPTHWISE_1x5_s2_p2_IP": 0,
        "DEPTHWISE_2x5_s2_p2_IP": 0,
        "DEPTHWISE_5x5_s1_p2_IP": 6.36,
        "DEPTHWISE_5x5_s2_p2_IP": 6.11,
        "DEPTHWISE_7x1_s2_p3_IP": 0,
        "DEPTHWISE_7x2_s2_p3_IP": 0,
        "DEPTHWISE_1x7_s2_p3_IP": 0,
        "DEPTHWISE_2x7_s2_p3_IP": 0,
        "DEPTHWISE_7x7_s1_p3_IP": 9.96,
        "DEPTHWISE_7x7_s2_p3_IP": 9.95,
        "RUNTIME": 37.96,  # including invoke
    }

    def __allocateBinaryCode(self):
        op_list = []
        for l in self.layer:
            codeSize, codeStr = self.__getOpCodeSize(l)
            if codeStr == None or codeStr in op_list:
                continue  # skip native or repeated functions
            else:
                self.code += float(codeSize)
                op_list.append(codeStr)

        self.code += self.CodeSizeTable["RUNTIME"]

    def __getOpCodeSize(self, op):
        layer = op.get_layer_info()
        if layer["op"] == "CONV_2D":
            if layer["kernel_h"] == 1 and layer["padding"] == 0:
                tagStr = "CONV_1x1"
            else:
                tagStr = (
                    "CONV_"
                    + str(layer["kernel_h"])
                    + "x"
                    + str(layer["kernel_w"])
                    + "_s"
                    + str(layer["stride_h"])
                    + "_p"
                    + str(layer["padding"])
                )

            return self.CodeSizeTable[tagStr], tagStr
        elif layer["op"] == "DEPTHWISE_CONV_2D":
            if self.USE_INPLACE:
                tagStr = (
                    "DEPTHWISE_"
                    + str(layer["kernel_h"])
                    + "x"
                    + str(layer["kernel_w"])
                    + "_s"
                    + str(layer["stride_h"])
                    + "_p"
                    + str(layer["padding"])
                    + "_IP"
                )
            else:
                tagStr = (
                    "DEPTHWISE_"
                    + str(layer["kernel_h"])
                    + "x"
                    + str(layer["kernel_w"])
                    + "_s"
                    + str(layer["stride_h"])
                    + "_p"
                    + str(layer["padding"])
                )

            return self.CodeSizeTable[tagStr], tagStr

        return None, None

    def __increaseFlash(self, size):
        self.flash += int(size / (8 / self.BIT))

    def __increaseBias(self, size):
        self.bias += size

    def __increaseScale(self, size):
        self.scale += size

    def __getSEBufferAddress(
        self, SE_inputLocation, SE_inputSize, SE_location, tensorSize
    ):
        if SE_inputLocation == "front":
            if SE_location == "head":
                return SE_inputSize
            elif SE_location == "tail":
                return self.buffers["input_output"] - tensorSize
        elif SE_inputLocation == "end":
            if SE_location == "head":
                return 0
            elif SE_location == "tail":
                return self.buffers["input_output"] - SE_inputSize - tensorSize
        else:
            raise Exception("unexpected tensor location")

    def __getBufferAddress(self, location, tensorSize):
        if location == "front":
            return 0
        elif location == "end":
            return self.buffers["input_output"] - tensorSize
        elif location == "residual":
            return 0
        elif location.startswith("stage"):
            return 0
        elif location.startswith("dagop"):
            return 0
        else:
            raise Exception("unexpected tensor location")

    def __flatsize(self, params, target_str):
        ret_size = 0

        if target_str == "input":
            if params["input_dim"] >= 3:
                ret_size = params["input_h"] * params["input_w"] * params["input_c"]
            elif params["input_dim"] == 2:
                ret_size = params["input_h"] * params["input_c"]
        elif target_str == "input2":
            if params["input2_dim"] >= 3:
                ret_size = params["input2_h"] * params["input2_w"] * params["input_c"]
            elif params["input2_dim"] == 2:
                ret_size = params["input2_h"] * params["input_c"]
        elif target_str == "output":
            if params["output_dim"] >= 3:
                ret_size = params["output_h"] * params["output_w"] * params["output_c"]
            elif params["output_dim"] == 2:
                ret_size = params["output_h"] * params["output_c"]

        return ret_size

    def __enlargeBuffer(self, buf_str, size):
        if buf_str == "input_output" or buf_str == "residual":
            self.buffers[buf_str] = max(
                self.buffers[buf_str], int(size / (8 / self.BIT))
            )
        else:
            if buf_str not in self.buffers:
                self.buffers[buf_str] = size
            else:
                self.buffers[buf_str] = max(self.buffers[buf_str], size)
