import math
from .base_allocator import BaseAllocator

__all__ = ["FirstFit"]


class slot:
    def __init__(self, y0: int, y1: int) -> None:
        self.y0 = y0
        self.y1 = y1

    def size(self):
        return self.y1 - self.y0


class FirstFit(BaseAllocator):
    def fit(self, rec) -> int:
        start, end, size = rec["start"], rec["end"], rec["size"]
        slots = []
        slots.append(slot(0, self.SRAM))

        insert_r = range(start, end)
        for cnt, rec in enumerate(self.rectangles):
            if rec["placement"] != -1:  # this each placed rectangle
                if (
                    start < rec["start"] < end
                    or start < rec["end"] < end
                    or rec["start"] < start < rec["end"]
                    or rec["start"] < end < rec["end"]
                ):  # overlap with the insert block
                    # placement of the rectatngle
                    y0 = rec["placement"]
                    if (
                        rec["stride2_inplace_idx"] is not None
                        and start > rec["stride2_inplace_idx"]
                    ):
                        y1 = y0 + math.ceil(rec["size"] / 4)
                    else:
                        y1 = y0 + rec["size"]
                    rec_y = range(y0, y1)

                    for s in slots:
                        if (
                            s.y0 <= y0 <= s.y1
                            or s.y0 <= y1 <= s.y1
                            or y0 <= s.y0 <= y1
                            or y0 <= s.y1 <= y1
                        ):  # overlap with the insert block
                            slots.append(slot(s.y0, y0))
                            slots.append(slot(y1, s.y1))
                            slots.remove(s)
                            break

        # use the first available
        lowest_slot = None
        lowest_slot_starting = 2**31 - 1
        for s in slots:
            if s.size() >= size:  # take this slot
                if lowest_slot_starting > s.y0:
                    lowest_slot_starting = s.y0
                    lowest_slot = s

        assert (
            lowest_slot is not None
        ), "no available slot, memory exceed MAX SRAM setting"
        return lowest_slot_starting
