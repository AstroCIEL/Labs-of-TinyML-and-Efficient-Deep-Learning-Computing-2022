from .TfliteConvertor import TfliteConvertor
from .MemoryScheduler import MemoryScheduler
from .PatchBasedUtil import getPatchParams
from .GeneralMemoryScheduler import GeneralMemoryScheduler
from tempfile import TemporaryDirectory
from .CodeGenerator import CodeGenerator

import os

def GenerateSourceFilesFromTFlite(
    tflite_path,
    life_cycle_path=None,
    custom_optimization_config={},
):
    default_optimization_config = {
        "loop_reordering": False, # Enable loop reordering optimization
        "im2col": False, # Enable im2col convolution
        "hwc2chw_weight": False, # Enable HWC -> CHW format transformation for weights
        "loop_unrolling": False, # Enable loop unrolling optimization
        "simd": False, # Enable SIMD programming
        "inplace_depthwise": False, # Enable inplace depthwise convolution
    }
    default_optimization_config.update(custom_optimization_config)
    use_reordering = default_optimization_config["loop_reordering"]
    use_im2col = default_optimization_config["im2col"]
    use_hwc2chw = default_optimization_config["hwc2chw_weight"]
    use_unrolling = default_optimization_config["loop_unrolling"]
    use_simd = default_optimization_config["simd"]
    use_inplace = default_optimization_config["inplace_depthwise"]
    with TemporaryDirectory() as WORKING_DIR:
        if life_cycle_path is None:
            schedule_image_path = os.path.join(WORKING_DIR, "schedule.png")
        else:
            schedule_image_path = life_cycle_path

        tf_convertor = TfliteConvertor(
            tflite_path
        )
        tf_convertor.parseOperatorInfo()
        layer = tf_convertor.layer
        outTable = []
        VisaulizeTrainable = False  # disable for code gen
        memory_scheduler = GeneralMemoryScheduler(
            layer,
            False,
            False,
            outputTables=outTable,
            inplace=use_inplace,
            mem_visual_path=schedule_image_path,
            VisaulizeTrainable=VisaulizeTrainable,
        )
        memory_scheduler.USE_INPLACE = use_inplace
        MemoryScheduler.USE_INPLACE = use_inplace
        memory_scheduler.allocateMemory()
        memory_scheduler.dumpLayerIndex()

        outTable = tf_convertor.outputTables if hasattr(tf_convertor, "outputTables") else []
        code_generator = CodeGenerator(
            memsche=memory_scheduler,
            inplace=memory_scheduler.USE_INPLACE,
            unsigned_input=False,
            patch_params=None,
            FP_output=False,
            profile_mode=False,
            fp_requantize=True,
            tflite_op=False,
            dummy_address=False,
            use_reordering=use_reordering,
            use_im2col=use_im2col,
            use_hwc2chw=use_hwc2chw,
            use_unrolling=use_unrolling,
            use_simd=use_simd,
            use_inplace=use_inplace,
            outputTables=outTable,
        )
        # set detection outputs before codegen if any
        code_generator.codeGeneration()

        return memory_scheduler.buffers["input_output"]
