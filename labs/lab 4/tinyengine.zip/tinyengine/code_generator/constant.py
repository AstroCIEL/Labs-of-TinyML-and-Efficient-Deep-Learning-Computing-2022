# end: for forcelly cast to fp32
TTYPE_STATIC_WEIGHT = "static_weights"
TTYPE_TRAINING_ACTIVATION = "training_activation"
TTYPE_TRAINING_WEIGHTS = "training_weight"
TTYPE_TRAINING_GRADIENT = "training_gradient"
TTYPE_INFERNECE = "inference"

# template 3
FIGURE_CONFIG = {
    "TRAIN_TENSOR_COLOR": "#68ac14",  # green
    "TRAIN_WEIGHT_COLOR": "#61a78f",  # light green:
    "TRAIN_ACTIVATION_COLOR": "#b9c8d8",  # light blue
    "TRAIN_GRADIENT_COLOR": "#35619f",  # blue
    "INFERENCE_COLOR": "#eab11f",  # yellow
    "FIGURE_W_INCH": 19,
    "FIGURE_H_INCH": 7,
    "DPI": 800,
    "FONT_SIZE": 32,
    "INDEX_FONT_SIZE": 24,
    "Y_STEP": 32,
    "Y_MAX": 128,
    "X_STEP": 5,
    "X_MAX": 60,
    "SHOW_INDEX": True,
}

op_name_translation = {
    "nn.conv2d": ["CONV_2D", "DEPTHWISE_CONV_2D", "GROUP_CONV"],
    "nn.mcuconv2d": ["CONV_2D", "DEPTHWISE_CONV_2D", "GROUP_CONV"],
    "nn.mcuadd": "ADD",
    "add": "ADD",
}
