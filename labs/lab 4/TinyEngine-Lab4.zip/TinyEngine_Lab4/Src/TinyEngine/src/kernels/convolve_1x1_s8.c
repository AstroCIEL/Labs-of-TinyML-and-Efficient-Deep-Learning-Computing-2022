/* ----------------------------------------------------------------------
 * Project: TinyEngine
 * Target ISA:  ARMv7E-M
 * Reference papers:
 * 	- MCUNet: Tiny Deep Learning on IoT Device, NIPS 2020
 *	- MCUNetV2: Memory-Efficient Patch-based Inference for Tiny Deep Learning, NIPS 2021
 * Contact authors: 
 *	- Wei-Ming Chen, wmchen@mit.edu
 *	- Wei-Chen Wang, wweichen@mit.edu
 * -------------------------------------------------------------------- */
#include "arm_nnfunctions.h"
#include "img2col_element.h"
#include "tinyengine_function.h"
#include "macro.h"

#define DIM_KER_X (1U)
#define DIM_KER_Y (1U)
#define STRIDE (1U)
#define PAD (0U)

tinyengine_status convolve_1x1_s8(const q7_t *input, const uint16_t input_x,
		const uint16_t input_y, const uint16_t input_ch, const q7_t *kernel,
		const int32_t *bias, const int32_t *output_shift,
		const int32_t *output_mult, const int32_t out_offset,
		const int32_t input_offset, const int32_t out_activation_min,
		const int32_t out_activation_max, q7_t *output, const uint16_t output_x,
		const uint16_t output_y, const uint16_t output_ch, q15_t *runtime_buf) {
#if SIMD
	int32_t i_element;
	(void) input_x;
	(void) input_y;

	/* Partial(two columns) im2col buffer */
	q15_t *two_column_buffer = runtime_buf;
	q7_t *out = output;
	const int32_t num_elements = output_x * output_y;
	const int channel_div4 = (input_ch >> 2);

	const int16_t inoff16 = input_offset;
	q31_t offset_q15x2 = __PKHBT(inoff16, inoff16, 16);
	const int batches = 1;


#if LOOP_REORDERING
	for (i_element = 0; i_element < num_elements / 2; i_element++) {
		/* Fill buffer for partial im2col - two columns at a time */
		q7_t *src = &input[i_element * input_ch * 2];
#else  // if (!LOOP_REORDERING)
	for (int batch = 0; batch < batches; ++batch) {
		for (int out_y = 0; out_y < output_y; ++out_y) {
			//const int in_y_origin = (out_y * stride_height) - pad_height;
			for (int out_x = 0; out_x < output_x / 2; ++out_x) {
				//const int in_x_origin = (out_x * stride_width) - pad_width;
				q7_t *src = &input[(out_y * output_x + out_x) * input_ch * 2];
#endif  // end of LOOP_REORDERING

				q15_t *dst = two_column_buffer;

				//use variables
				q31_t in_q7x4;
				q31_t in_q15x2_1;
				q31_t in_q15x2_2;
				q31_t out_q15x2_1;
				q31_t out_q15x2_2;

				int cnt = channel_div4;	//two columns
				while (cnt > 0) {
					q7_q15_offset_reordered_ele(src, dst)
					q7_q15_offset_reordered_ele(src, dst)
					cnt--;
				}

				out = arm_nn_mat_mult_kernel_s8_s16_reordered(kernel,
						two_column_buffer, output_ch, output_shift, output_mult,
						(q7_t) out_offset, out_activation_min,
						out_activation_max, input_ch * DIM_KER_Y * DIM_KER_X,
						bias, out);

#if LOOP_REORDERING
	}

	/* check if there is an odd column left-over for computation */
	if (num_elements & 0x1) {
		int32_t i_ch_out;
		const q7_t *ker_a = kernel;
		q7_t *src = &input[(num_elements - 1) * input_ch];
		q15_t *dst = two_column_buffer;

		//use variables
		q31_t in_q7x4;
		q31_t in_q15x2_1;
		q31_t in_q15x2_2;
		q31_t out_q15x2_1;
		q31_t out_q15x2_2;

		int cnt = channel_div4;	//two * numof2col columns
		while (cnt > 0) {
			q7_q15_offset_reordered_ele(src, dst)
			cnt--;
		}

		for (i_ch_out = 0; i_ch_out < output_ch; i_ch_out++) {
			q31_t sum = bias[i_ch_out];

			/* Point to the beginning of the im2col buffer where the input is available as a rearranged column */
			const q15_t *ip_as_col = runtime_buf;
			uint16_t col_count = (input_ch * DIM_KER_X * DIM_KER_Y) >> 2;

			while (col_count) {
				q31_t ker_a1, ker_a2;
				q31_t in_b1, in_b2;
				ker_a = read_and_pad_reordered(ker_a, &ker_a1, &ker_a2);

				in_b1 = arm_nn_read_q15x2_ia(&ip_as_col);
				sum = __SMLAD(ker_a1, in_b1, sum);
				in_b2 = arm_nn_read_q15x2_ia(&ip_as_col);
				sum = __SMLAD(ker_a2, in_b2, sum);

				col_count--;
			}

			sum = arm_nn_requantize(sum, output_mult[i_ch_out],
					output_shift[i_ch_out]);
			sum += out_offset;
			sum = MAX(sum, out_activation_min);
			sum = MIN(sum, out_activation_max);
			*out++ = (q7_t) sum;
		}
	}
#else  // if (!LOOP_REORDERING)
			}
		}
	}
#endif  // end of LOOP_REORDERING

#else
	/* TFLite-like Implementation */
	// Get parameters.
	const int stride_width = STRIDE;
	const int stride_height = STRIDE;
	const int dilation_width_factor = 1;
	const int dilation_height_factor = 1;
	const int pad_width = PAD;
	const int pad_height = PAD;
	const int batches = 1;

	const int filter_input_ch = input_ch;
	const int groups = input_ch / filter_input_ch;
	const int filters_per_group = output_ch / groups;

#if LOOP_REORDERING
	int32_t i_element;
	int out_y = 0;
	int out_x = 0;
	int batch = 0;
	const int32_t num_elements = output_x * output_y;
	for (i_element = 0; i_element < num_elements; i_element++) {
		const int in_y_origin = (out_y * stride_height) - pad_height;
		const int in_x_origin = (out_x * stride_width) - pad_width;
#else
	for (int batch = 0; batch < batches; ++batch) {
		for (int out_y = 0; out_y < output_y; ++out_y) {
			const int in_y_origin = (out_y * stride_height) - pad_height;
			for (int out_x = 0; out_x < output_x; ++out_x) {
				const int in_x_origin = (out_x * stride_width) - pad_width;
#endif
				for (int out_channel = 0; out_channel < output_ch; ++out_channel) {
					auto group = out_channel / filters_per_group;
					int32_t acc = 0;
					for (int filter_y = 0; filter_y < DIM_KER_Y; ++filter_y) {
						const int in_y = in_y_origin + dilation_height_factor * filter_y;
						for (int filter_x = 0; filter_x < DIM_KER_X; ++filter_x) {
							const int in_x = in_x_origin + dilation_width_factor * filter_x;

							// Zero padding by omitting the areas outside the image.
							const bool is_point_inside_image = (in_x >= 0) && (in_x < input_x) && (in_y >= 0) && (in_y < input_y);

							if (!is_point_inside_image) {
								continue;
							}

							for (int in_channel = 0; in_channel < filter_input_ch; ++in_channel) {
								int32_t input_val = input[Offset(input_y, input_x, input_ch, batch, in_y, in_x, in_channel + group * filter_input_ch)];
								int32_t filter_val = kernel[Offset(DIM_KER_Y, DIM_KER_X, input_ch, out_channel, filter_y, filter_x, in_channel)];
								// Accumulate with 32 bits accumulator.
								// In the nudging process during model quantization, we force
								// real value of 0.0 be represented by a quantized value. This
								// guarantees that the input_offset is a int8_t, even though
								// it is represented using int32_t. int32_t += int8_t *
								// (int8_t - int8_t) so the highest value we can get from each
								// accumulation is [-127, 127] * ([-128, 127] -
								// [-128, 127]), which is [-32512, 32512]. log2(32512)
								// = 14.98, which means we can accumulate at least 2^16
								// multiplications without overflow. The accumulator is
								// applied to a filter so the accumulation logic will hold as
								// long as the filter size (filter_y * filter_x * in_channel)
								// does not exceed 2^16, which is the case in all the models
								// we have seen so far.
								// TODO(b/174275578): Add a check to make sure the
								// accumulator depth is smaller than 2^16.
								acc += filter_val * (input_val + input_offset);
							}
						}
					}

					if (bias) {
						acc += bias[out_channel];
					}
					acc = MultiplyByQuantizedMultiplier(acc, output_mult[out_channel], output_shift[out_channel]);
					acc += out_offset;
					acc = MAX(acc, out_activation_min);
					acc = MIN(acc, out_activation_max);
					output[Offset(output_y, output_x, output_ch, batch, out_y, out_x, out_channel)] = (int8_t)(acc);
				}
#if LOOP_REORDERING
		out_x++;
		if(out_x == output_x){
			out_y++;
			out_x = 0;
		}
	}
#else
			}
		}
	}
#endif
#endif

	/* Return to application */
	return STATE_SUCCESS;
}
