/* ----------------------------------------------------------------------
 * Project: TinyEngine
 * Target ISA:  ARMv7E-M
 * Reference papers:
 *  - MCUNet: Tiny Deep Learning on IoT Device, NIPS 2020
 *  - MCUNetV2: Memory-Efficient Patch-based Inference for Tiny Deep Learning, NIPS 2021
 * Contact author:
 *  - Wei-Ming Chen, wmchen@mit.edu
 *  - Wei-Chen Wang, wweichen@mit.edu
 *  - Ji Lin, jilin@mit.edu
 *  - Song Han, songhan@mit.edu
 * -------------------------------------------------------------------- */
#include "tinyengine_function.h"

int OffsetC(const uint16_t data1, const uint16_t data2, const uint16_t data3, int i0, int i1, int i2, int i3) {
  return ((i0 * data1 + i1) * data2 + i2) * data3 + i3;
}
