/* Automatically generated header file */
/* ----------------------------------------------------------------------
 * Project: TinyEngine (Lab 4 of MIT TinyML and Efficient Deep Learning Computing Course (6.S965))
 * Reference papers:
 * 	- MCUNet: Tiny Deep Learning on IoT Device, NIPS 2020
 *	- MCUNetV2: Memory-Efficient Patch-based Inference for Tiny Deep Learning, NIPS 2021
 * Contact authors: 
 *	- Wei-Chen Wang, wweichen@mit.edu
 *	- Wei-Ming Chen, wmchen@mit.edu
 * -------------------------------------------------------------------- */

#define TRUE  (1==1)
#define FALSE (!TRUE)

#define LOOP_REORDERING FALSE
#define IM2COL FALSE
#define HWC2CHW_WEIGHT FALSE
#define LOOP_UNROLLING FALSE
#define SIMD FALSE
#define INPLACE_DEPTHWISE FALSE
